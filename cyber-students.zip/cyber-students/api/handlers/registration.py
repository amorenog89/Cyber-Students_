from json import dumps
from logging import info
from tornado.escape import json_decode, utf8
from tornado.gen import coroutine

from .base import BaseHandler

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
from cryptography.hazmat.primitives import hashes


class RegistrationHandler(BaseHandler):

    @coroutine
    def post(self):

        key="mykey"
        key_bytes=bytes(key, "utf-8")
        rc4_cipher= Cipher(algorithms.ARC4(key_bytes), mode=None)
        rc4_encryptor = rc4_cipher.encryptor()
        rc4_decryptor= rc4_cipher.decryptor()
        try:
            body = json_decode(self.request.body)
            email = body['email'].lower().strip()
            if not isinstance(email, str):
                raise Exception()
            password = body['password']
            if not isinstance(password, str):
                raise Exception()
            display_name = body.get('displayName')
            if display_name is None:
                display_name = email
            if not isinstance(display_name, str):
                raise Exception()
        except Exception as e:
            self.send_error(400, message='You must provide an email address, password and display name!')
            return

        if not email:
            self.send_error(400, message='The email address is invalid!')
            return

        if not password:
            self.send_error(400, message='The password is invalid!')
            return

        if not display_name:
            self.send_error(400, message='The display name is invalid!')
            return

        user = yield self.db.users.find_one({
          'email': email  
        }, {})

        if user is not None:
            self.send_error(409, message='A user with the given email address already exists!')
            return

        digest=hashes.Hash(hashes.MD5())
        digest.update(password)
        hashpassword= digest.finalize()


        email_bytes=bytes(email, "utf-8")
        cipherEmail_bytes= rc4_encryptor.update(email_bytes)
        cipherEmail=cipherEmail_bytes.hex()

        display_name_bytes= bytes(display_name, "utf-8")
        cipherName_bytes= rc4_encryptor.update(display_name_bytes)
        cipherName=cipherEmail_bytes.hex()

        yield self.db.users.insert_one({
            #'email': email,
            #'password': password,
            #'displayName': display_name

            'email': cipherEmail,
            'password': hashpassword,
            'displayName': cipherName
        })


    

        self.set_status(200)
        #self.response['email'] = email
        #self.response['displayName'] = display_name

        self.response['email'] = cipherEmail
        self.response['displayName'] = cipherName

        self.write_json()
